package ir.shabro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 12)
    private val panel = Color.rgb(29, 27, 22)
    private val gold = Color.rgb(242, 193, 78)
    private val cream = Color.rgb(247, 239, 219)
    private val muted = Color.rgb(190, 180, 155)
    private val orders = mutableListOf<Order>()
    private var basePassenger = 30000.0
    private var perKmPassenger = 8000.0
    private var baseCargo = 50000.0
    private var perKmCargo = 12000.0
    private var nightPercent = 20.0
    private var commission = 5.0
    private var currentQuote = 0.0
    private var currentTab = "customer"
    private lateinit var content: LinearLayout
    private lateinit var root: LinearLayout

    data class Order(val kind:String, val from:String, val to:String, val km:Int, val price:Double, var status:String="در انتظار راننده")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        showApp()
    }

    private fun showApp() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        val header = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(22,22,22,18); setBackgroundColor(Color.rgb(8,8,8))
        }
        header.addView(label("☾  شب‌رو", 27f, gold, true))
        header.addView(label("سامانه جابه‌جایی مسافر و حمل بار در سراسر ایران", 13f, muted))
        root.addView(header)
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(8,10,8,8); gravity=Gravity.CENTER }
        listOf("ثبت درخواست" to "customer", "پنل راننده" to "driver", "سفارش‌ها" to "orders", "مدیریت" to "admin").forEach { (title,key) ->
            val b=Button(this).apply {
                text=title; textSize=11f; isAllCaps=false
                setTextColor(if(currentTab==key) Color.BLACK else cream)
                setBackgroundColor(if(currentTab==key) gold else panel)
                setOnClickListener { currentTab=key; showContent() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(3,0,3,0) })
        }
        root.addView(nav)
        val scroll=ScrollView(this).apply { isFillViewport=true }
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,8,14,20) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        showContent()
    }

    private fun showContent() {
        content.removeAllViews()
        when(currentTab) {
            "customer" -> customerPage()
            "driver" -> driverPage()
            "orders" -> ordersPage()
            "admin" -> adminPage()
        }
    }

    private fun customerPage() {
        card("ثبت درخواست جدید") {
            val kind=spinner(listOf("جابه‌جایی مسافر","حمل بار و بسته"))
            val vehicle=spinner(listOf("سواری","وانت","کامیونت"))
            val from=edit("شهر یا نشانی مبدأ")
            val to=edit("شهر یا نشانی مقصد")
            val km=edit("مسافت تقریبی به کیلومتر", true)
            val period=spinner(listOf("شب","روز"))
            val phone=edit("شماره تماس")
            addView(kind); addView(vehicle); addView(from); addView(to); addView(km); addView(period); addView(phone)
            val quote=label("کرایه پس از محاسبه نمایش داده می‌شود",18f,gold,true)
            addView(quote)
            addView(actionButton("محاسبه کرایه") {
                val distance=km.text.toString().toIntOrNull() ?: 0
                if(from.text.isBlank() || to.text.isBlank() || distance<=0) {
                    toast("مبدأ، مقصد و مسافت معتبر را وارد کن.")
                } else {
                    val cargo=kind.selectedItemPosition==1
                    val raw=(if(cargo) baseCargo else basePassenger)+distance*(if(cargo) perKmCargo else perKmPassenger)
                    currentQuote=raw*(if(period.selectedItemPosition==0) 1+nightPercent/100 else 1.0)
                    quote.text="کرایه تخمینی: ${money(currentQuote)}\nکمیسیون شب‌رو: ${money(currentQuote*commission/100)}"
                }
            })
            addView(actionButton("ثبت سفارش آزمایشی") {
                val distance=km.text.toString().toIntOrNull() ?: 0
                if(currentQuote<=0 || distance<=0 || from.text.isBlank() || to.text.isBlank()) toast("ابتدا اطلاعات را کامل و کرایه را محاسبه کن.")
                else {
                    orders.add(0,Order(if(kind.selectedItemPosition==0) "مسافر" else "بار",from.text.toString(),to.text.toString(),distance,currentQuote))
                    currentQuote=0.0; toast("سفارش آزمایشی ثبت شد."); currentTab="orders"; showContent()
                }
            })
        }
        card("شب‌رو در یک نگاه") {
            addView(label("نوع خدمات:  مسافر   و   بار",16f,cream,true))
            addView(label("محدوده فعالیت:  سراسر ایران",16f,cream,true))
            addView(label("کمیسیون اولیه:  ۵ درصد",16f,gold,true))
            addView(label("این نسخه برای بررسی ظاهر و جریان کار است. هنوز به سرور، نقشه، پیامک و پرداخت واقعی متصل نیست.",13f,muted))
        }
    }

    private fun driverPage() {
        card("پنل راننده") {
            addView(label("درخواست‌های ثبت‌شده در همین گوشی",14f,muted))
            val open=orders.filter { it.status=="در انتظار راننده" }
            if(open.isEmpty()) addView(label("فعلاً سفارش بازی وجود ندارد.",14f,muted))
            open.forEach { o ->
                addView(label("${o.kind}: ${o.from}  ←  ${o.to}",15f,cream,true))
                addView(label("${o.km} کیلومتر  •  ${money(o.price)}",13f,muted))
                addView(actionButton("قبول سفارش") { o.status="راننده پذیرفت"; toast("سفارش در نسخه آزمایشی پذیرفته شد."); showContent() })
                addView(space())
            }
        }
        card("مشخصات راننده (نمونه)") {
            addView(edit("نام راننده")); addView(edit("شماره تماس")); addView(edit("نوع خودرو")); addView(edit("شهر فعالیت"))
            addView(label("احراز هویت و مدارک راننده در نسخه آنلاین اضافه می‌شود.",12f,muted))
        }
    }

    private fun ordersPage() {
        card("سفارش‌ها") {
            if(orders.isEmpty()) addView(label("هنوز سفارشی ثبت نشده است.",14f,muted))
            orders.forEach { o ->
                addView(label("${o.kind}  •  ${o.status}",16f,gold,true))
                addView(label("${o.from}  ←  ${o.to}",15f,cream))
                addView(label("${o.km} کیلومتر  •  ${money(o.price)}",13f,muted))
                addView(space())
            }
        }
    }

    private fun adminPage() {
        card("تنظیم تعرفه‌های آزمایشی (تومان)") {
            val pb=edit("پایه مسافر",true).apply { setText(basePassenger.toInt().toString()) }
            val pk=edit("هزینه هر کیلومتر مسافر",true).apply { setText(perKmPassenger.toInt().toString()) }
            val cb=edit("پایه بار",true).apply { setText(baseCargo.toInt().toString()) }
            val ck=edit("هزینه هر کیلومتر بار",true).apply { setText(perKmCargo.toInt().toString()) }
            val night=edit("افزایش شب‌کاری درصد",true).apply { setText(nightPercent.toInt().toString()) }
            val fee=edit("کمیسیون درصد",true).apply { setText(commission.toInt().toString()) }
            listOf(pb,pk,cb,ck,night,fee).forEach { addView(it) }
            addView(actionButton("ذخیره تعرفه‌ها") {
                basePassenger=pb.num(basePassenger); perKmPassenger=pk.num(perKmPassenger)
                baseCargo=cb.num(baseCargo); perKmCargo=ck.num(perKmCargo)
                nightPercent=night.num(nightPercent); commission=fee.num(commission)
                toast("تعرفه‌های نمونه ذخیره شد.")
            })
        }
        card("یادآوری") { addView(label("نرخ‌ها فرضی هستند و قبل از بهره‌برداری باید بر اساس شهر، مسیر، هزینه سوخت و قوانین روز تعیین شوند.",13f,muted)) }
    }

    private fun card(title:String, body:LinearLayout.()->Unit) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(17,16,17,18); setBackgroundColor(panel) }
        box.addView(label(title,19f,gold,true))
        box.addView(space(8))
        box.body()
        content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(14) })
    }
    private fun label(text:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply {
        this.text=text; textSize=size; setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD)
        gravity=Gravity.RIGHT; setPadding(2,dp(7),2,dp(7)); textDirection=View.TEXT_DIRECTION_RTL
        layoutDirection=View.LAYOUT_DIRECTION_RTL
    }
    private fun edit(hint:String,numeric:Boolean=false)=EditText(this).apply {
        this.hint=hint; textSize=14f; setTextColor(cream); setHintTextColor(muted)
        setSingleLine(true); setPadding(dp(12),dp(10),dp(12),dp(10))
        setBackgroundColor(Color.rgb(15,15,15)); inputType=if(numeric) 2 else 1
        layoutDirection=View.LAYOUT_DIRECTION_RTL
        val lp=LinearLayout.LayoutParams(-1,dp(52)); lp.bottomMargin=dp(9); this.layoutParams=lp
    }
    private fun spinner(items:List<String>)=Spinner(this).apply {
        adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items)
        setBackgroundColor(Color.rgb(15,15,15))
        layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply { bottomMargin=dp(9) }
    }
    private fun actionButton(text:String,onClick:()->Unit)=Button(this).apply {
        this.text=text; textSize=14f; isAllCaps=false; setTextColor(Color.BLACK); setBackgroundColor(gold)
        setOnClickListener { onClick() }
        layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply { topMargin=dp(6); bottomMargin=dp(6) }
    }
    private fun space(h:Int=12)=View(this).apply { layoutParams=LinearLayout.LayoutParams(1,dp(h)) }
    private fun money(n:Double)=NumberFormat.getNumberInstance(Locale("fa","IR")).format(n.toLong())+" تومان"
    private fun EditText.num(default:Double)=text.toString().toDoubleOrNull() ?: default
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
