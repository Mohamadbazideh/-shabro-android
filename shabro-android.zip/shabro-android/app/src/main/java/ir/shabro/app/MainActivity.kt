package ir.shabro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 10, 14)
    private val panel = Color.rgb(20, 21, 26)
    private val gold = Color.rgb(242, 185, 59)
    private val white = Color.rgb(246, 244, 238)
    private val muted = Color.rgb(164, 163, 160)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun shape(color: Int, radius: Float, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(null, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_RTL
    }
    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(12)) }
        header.addView(text("☾", 28f, gold, true), LinearLayout.LayoutParams(dp(42), dp(42)))
        header.addView(text(title, 25f, gold, true), LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(text("☰", 24f, white), LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(header)
        setContentView(root)
    }
    private fun card(content: View, height: Int = -2, color: Int = panel): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); background = shape(color, dp(20).toFloat(), Color.rgb(55,48,34))
        addView(content, LinearLayout.LayoutParams(-1, height))
    }
    private fun button(label: String, onClick: () -> Unit): TextView = text(label, 17f, if (label.contains("درخواست") || label.contains("ارسال")) gold else white, true).apply {
        background = shape(Color.rgb(13,14,18), dp(18).toFloat(), gold); setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { onClick() }
    }
    private fun showHome() {
        base("شب‌رو")
        val greeting = text("سفر امن، در هر زمان، در سراسر ایران", 14f, muted)
        root.addView(greeting, LinearLayout.LayoutParams(-1, dp(30)))
        val map = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(45,53,48), Color.rgb(24,32,32), Color.rgb(55,54,43))).apply { cornerRadius = dp(20).toFloat() }
            addView(text("✦      نقشه و موقعیت مکانی      ✦\n\n       ●\n   ────────\n       ◆", 18f, Color.rgb(215,218,198)), FrameLayout.LayoutParams(-1, -1))
            addView(text("مبدأ را انتخاب کنید   🔵\n\nمقصد را انتخاب کنید   📍", 14f, white, true).apply { background = shape(Color.rgb(15,16,20), dp(16).toFloat()); setPadding(dp(8), dp(8), dp(8), dp(8)) }, FrameLayout.LayoutParams(-1, dp(86), Gravity.BOTTOM))
        }
        root.addView(map, LinearLayout.LayoutParams(-1, dp(230)).apply { bottomMargin = dp(14) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(button("🚘\nدرخواست سفر") { showBooking("سفر مسافر") }, LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginEnd = dp(7) })
        actions.addView(button("📦\nارسال بار و بسته") { showBooking("ارسال بار و بسته") }, LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginStart = dp(7) })
        root.addView(actions)
        val promo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = shape(Color.rgb(22,20,16), dp(18).toFloat(), gold); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        promo.addView(text("شب‌رو", 22f, gold, true)); promo.addView(text("همیشه در کنار شماست", 14f, white))
        root.addView(promo, LinearLayout.LayoutParams(-1, dp(86)).apply { topMargin = dp(14) })
        val spacer = View(this); root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = shape(Color.rgb(17,18,22), dp(18).toFloat()); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        listOf("⌂\nخانه", "▣\nسفارش‌ها", "▤\nکیف پول", "☻\nپروفایل").forEachIndexed { i, s ->
            val item = text(s, 12f, if (i == 0) gold else muted, i == 0)
            nav.addView(item, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav)
        val admin = text("پنل راننده و مدیریت", 11f, muted).apply { setPadding(0, dp(8), 0, 0); setOnClickListener { showDriver() } }
        root.addView(admin)
    }
    private fun showBooking(kind: String) {
        base(kind)
        root.addView(text("مبدأ و مقصد سفر را وارد کنید", 18f, gold, true), LinearLayout.LayoutParams(-1, dp(56)))
        listOf("آدرس مبدأ", "آدرس مقصد", "توضیحات (اختیاری)").forEach { hint ->
            val e = EditText(this).apply { this.hint = hint; setHintTextColor(muted); setTextColor(white); textSize = 15f; background = shape(panel, dp(14).toFloat()); setPadding(dp(14), 0, dp(14), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
            root.addView(e, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) })
        }
        root.addView(button("ثبت درخواست (نسخه نمایشی)") { Toast.makeText(this, "این نسخه هنوز به سامانه آنلاین متصل نیست", Toast.LENGTH_LONG).show() }, LinearLayout.LayoutParams(-1, dp(58)))
        root.addView(button("بازگشت به خانه") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
    }
    private fun showDriver() {
        base("پنل راننده")
        root.addView(card(text("سلام راننده عزیز\nوضعیت: آفلاین\n\nتعداد سفرها: ۲۸\nدرآمد امروز: ۲٬۴۵۰٬۰۰۰ تومان", 17f, white, true)), LinearLayout.LayoutParams(-1, dp(230)))
        root.addView(button("نمایش نقشه و درخواست‌ها") { Toast.makeText(this, "اتصال آنلاین در نسخه بعدی اضافه می‌شود", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(16) })
        root.addView(button("تنظیمات مدیریت") { showAdmin() }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) })
        root.addView(button("بازگشت به خانه") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
    }
    private fun showAdmin() {
        base("تنظیمات مدیریت")
        root.addView(card(text("کمیسیون پلتفرم\n۵٪ از هر سفارش\n\nتعرفه‌ها و قیمت‌گذاری\nمدیریت کاربران\nگزارش‌گیری و آمار\nتنظیمات پیشرفته", 17f, white, true)), LinearLayout.LayoutParams(-1, dp(300)))
        root.addView(button("بازگشت به پنل راننده") { showDriver() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        root.addView(button("خانه") { showHome() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
    }
}
