package ir.shabro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 11)
    private val panel = Color.rgb(19, 20, 24)
    private val panel2 = Color.rgb(27, 27, 29)
    private val gold = Color.rgb(245, 190, 66)
    private val pale = Color.rgb(242, 232, 205)
    private val muted = Color.rgb(165, 158, 143)
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun label(s: String, size: Float, color: Int = pale, bold: Boolean = false, align: Int = Gravity.CENTER): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = align
        if (bold) setTypeface(null, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_RTL
        setLineSpacing(dp(3).toFloat(), 1f)
    }
    private fun makeButton(s: String, primary: Boolean = false, action: () -> Unit): TextView = label(s, 15f, if (primary) Color.rgb(20,18,13) else gold, true).apply {
        background = rounded(if (primary) gold else Color.rgb(14,15,18), 16, if (primary) 0 else Color.rgb(119,88,35))
        setPadding(dp(12), dp(14), dp(12), dp(14)); setOnClickListener { action() }
    }
    private fun addGap(parent: LinearLayout, h: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun sectionTitle(s: String): TextView = label(s, 18f, gold, true, Gravity.RIGHT).apply { setPadding(0, dp(8), dp(2), dp(12)) }

    private fun shell(title: String, showNav: Boolean = true) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(18)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (showNav) root.addView(bottomNav())
        setContentView(root)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(8), dp(2), dp(8)) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.shabro_logo); scaleType = ImageView.ScaleType.FIT_CENTER }
        header.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        header.addView(label(title, 25f, gold, true, Gravity.RIGHT or Gravity.CENTER_VERTICAL), LinearLayout.LayoutParams(0, dp(58), 1f))
        header.addView(label("☰", 25f, pale), LinearLayout.LayoutParams(dp(42), dp(48)))
        body.addView(header)
    }

    private fun bottomNav(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(14,15,18)); setPadding(dp(5), dp(7), dp(5), dp(7))
        val items = listOf("⌂\nخانه", "▣\nسفارش‌ها", "▤\nکیف پول", "●\nپروفایل")
        items.forEachIndexed { i, s ->
            val v = label(s, 11f, if (i == 0) gold else muted, i == 0)
            addView(v, LinearLayout.LayoutParams(0, dp(48), 1f))
            v.setOnClickListener { if (i == 1) showOrders() else if (i == 3) showProfile() else showHome() }
        }
    }

    private fun showHome() {
        shell("شب‌رو")
        body.addView(label("سفر امن، در هر زمان، در سراسر ایران", 14f, muted, false, Gravity.RIGHT), LinearLayout.LayoutParams(-1, dp(34)))
        addGap(body, 8)
        // Decorative night skyline banner
        val hero = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(9,12,20), Color.rgb(31,30,30), Color.rgb(69,48,23))).apply { cornerRadius = dp(22).toFloat() }
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val skyline = label("✦       ☾       ✦\n\n        ╱╲      ╱╲\n   ╱╲  ╱  ╲____╱  ╲\n━━━━━━━━━━━━━━━━━━", 19f, gold, true)
        hero.addView(skyline, FrameLayout.LayoutParams(-1, dp(142)))
        hero.addView(label("سفر امن، در هر زمان", 14f, pale, true).apply { setBackgroundColor(Color.argb(110, 0,0,0)) }, FrameLayout.LayoutParams(-1, dp(36), Gravity.BOTTOM))
        body.addView(hero, LinearLayout.LayoutParams(-1, dp(190)))
        addGap(body, 16)
        body.addView(sectionTitle("مقصدت کجاست؟"))
        val map = FrameLayout(this).apply { background = rounded(Color.rgb(29,37,34), 20); clipToOutline = true }
        map.addView(RoadMap(this), FrameLayout.LayoutParams(-1, dp(205)))
        val mapInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.rgb(13,14,17), 15); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        mapInfo.addView(label("🔵  مبدأ را انتخاب کنید", 14f, pale, true, Gravity.RIGHT))
        addGap(mapInfo, 6)
        mapInfo.addView(label("📍  مقصد را انتخاب کنید", 14f, pale, true, Gravity.RIGHT))
        val infoParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(10), 0, dp(10), dp(10)) }
        map.addView(mapInfo, infoParams)
        body.addView(map, LinearLayout.LayoutParams(-1, dp(225)))
        addGap(body, 14)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val trip = makeButton("🚘\nدرخواست سفر", true) { showBooking("درخواست سفر") }
        val cargo = makeButton("📦\nارسال بار و بسته", false) { showBooking("ارسال بار و بسته") }
        actions.addView(trip, LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginEnd = dp(6) })
        actions.addView(cargo, LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginStart = dp(6) })
        body.addView(actions)
        addGap(body, 14)
        val promo = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(Color.rgb(25,22,17), 18, Color.rgb(111,80,31)); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        promo.addView(label("🚘", 34f, gold), LinearLayout.LayoutParams(dp(62), dp(64)))
        val promoText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(label("شب‌رو", 20f, gold, true, Gravity.RIGHT)); addView(label("همیشه در کنار شماست", 12f, pale, false, Gravity.RIGHT)) }
        promo.addView(promoText, LinearLayout.LayoutParams(0, -2, 1f))
        body.addView(promo, LinearLayout.LayoutParams(-1, dp(88)))
        addGap(body, 16)
        val features = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; background = rounded(Color.rgb(17,18,21), 18); setPadding(dp(4), dp(12), dp(4), dp(12)) }
        listOf("🛡\nامنیت بالا", "♧\nپشتیبانی", "ϟ\nسفارش سریع", "⌖\nپوشش سراسری").forEach { features.addView(label(it, 11f, gold, true), LinearLayout.LayoutParams(0, dp(52), 1f)) }
        body.addView(features)
        addGap(body, 12)
        body.addView(label("پنل راننده  •  مدیریت", 12f, muted).apply { setOnClickListener { showDriver() } }, LinearLayout.LayoutParams(-1, dp(40)))
    }

    private class RoadMap(ctx: android.content.Context) : View(ctx) {
        private val road = Paint(3).apply { color = Color.rgb(99,105,94); strokeWidth = 5f; style = Paint.Style.STROKE }
        private val thin = Paint(3).apply { color = Color.rgb(66,77,68); strokeWidth = 2f; style = Paint.Style.STROKE }
        private val pin = Paint(3).apply { color = Color.rgb(244,185,53); style = Paint.Style.FILL }
        override fun onDraw(c: Canvas) { super.onDraw(c); val w=width.toFloat(); val h=height.toFloat()
            for (i in 0..5) { val x=w*i/5f; c.drawLine(x,0f,x+w*.18f,h,thin); val y=h*i/5f; c.drawLine(0f,y,w,y-h*.12f,thin) }
            val p=Path().apply { moveTo(-20f,h*.75f); lineTo(w*.3f,h*.48f); lineTo(w*.53f,h*.58f); lineTo(w*.78f,h*.22f); lineTo(w+20,h*.30f) }; c.drawPath(p,road)
            c.drawCircle(w*.36f,h*.48f,dp(7).toFloat(),pin); c.drawCircle(w*.78f,h*.22f,dp(6).toFloat(),pin)
        }
    }

    private fun showBooking(kind: String) {
        shell(kind, false)
        body.addView(sectionTitle("ثبت درخواست جدید"))
        listOf("مبدأ سفر", "مقصد سفر", "شهر یا نشانی مبدأ", "شهر یا نشانی مقصد", "زمان سفر", "شماره تماس").forEach { hint ->
            val e = EditText(this).apply { this.hint = hint; setHintTextColor(muted); setTextColor(pale); textSize = 15f; background = rounded(panel2, 14); setPadding(dp(14), 0, dp(14), 0); gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL; textDirection = View.TEXT_DIRECTION_RTL }
            body.addView(e, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(12) })
        }
        body.addView(makeButton("محاسبه کرایه", true) { Toast.makeText(this, "محاسبه آنلاین کرایه در نسخه آزمایشی فعال نیست", Toast.LENGTH_LONG).show() }, LinearLayout.LayoutParams(-1, dp(62)))
        addGap(body, 12)
        body.addView(makeButton("بازگشت به صفحه اصلی") { showHome() }, LinearLayout.LayoutParams(-1, dp(56)))
    }
    private fun showDriver() {
        shell("پنل راننده", false)
        body.addView(sectionTitle("سلام، راننده عزیز"))
        body.addView(label("●  وضعیت: آفلاین", 15f, gold, true), LinearLayout.LayoutParams(-1, dp(48)))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(stat("۲۸", "تعداد سفرها"), LinearLayout.LayoutParams(0, dp(110), 1f).apply { marginEnd = dp(6) })
        stats.addView(stat("۲٬۴۵۰٬۰۰۰", "درآمد امروز (تومان)"), LinearLayout.LayoutParams(0, dp(110), 1f).apply { marginStart = dp(6) })
        body.addView(stats)
        addGap(body, 14)
        body.addView(makeButton("نمایش نقشه و درخواست‌ها", true) { Toast.makeText(this,"اتصال آنلاین در نسخه بعدی فعال می‌شود",Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1,dp(58)))
        addGap(body, 10); body.addView(makeButton("تنظیمات مدیریت") { showAdmin() }, LinearLayout.LayoutParams(-1,dp(56)))
        addGap(body, 10); body.addView(makeButton("بازگشت به خانه") { showHome() }, LinearLayout.LayoutParams(-1,dp(56)))
    }
    private fun stat(value: String, caption: String) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(panel,18,Color.rgb(90,67,30)); addView(label(value,20f,gold,true)); addView(label(caption,12f,muted)) }
    private fun showAdmin() {
        shell("تنظیمات مدیریت", false)
        body.addView(sectionTitle("مدیریت سامانه شب‌رو"))
        body.addView(stat("۵٪", "کمیسیون پلتفرم از هر سفارش"), LinearLayout.LayoutParams(-1,dp(115)))
        listOf("تعرفه‌ها و قیمت‌گذاری", "مدیریت کاربران", "گزارش‌گیری و آمار", "تنظیمات پیشرفته").forEach { s -> addGap(body,9); body.addView(label("‹     $s",16f,pale,true,Gravity.RIGHT).apply { background=rounded(panel,14); setPadding(dp(14),dp(16),dp(14),dp(16)) },LinearLayout.LayoutParams(-1,dp(58))) }
        addGap(body,14); body.addView(makeButton("بازگشت به پنل راننده") { showDriver() },LinearLayout.LayoutParams(-1,dp(54)))
        addGap(body,10); body.addView(makeButton("خانه") { showHome() },LinearLayout.LayoutParams(-1,dp(54)))
    }
    private fun showOrders() { shell("سفارش‌های من", false); body.addView(label("هنوز سفارشی ثبت نکرده‌اید",16f,muted),LinearLayout.LayoutParams(-1,dp(150))); body.addView(makeButton("ثبت درخواست جدید",true){showBooking("درخواست سفر")}) }
    private fun showProfile() { shell("پروفایل کاربری", false); body.addView(label("به شب‌رو خوش آمدید",18f,gold,true),LinearLayout.LayoutParams(-1,dp(90))); body.addView(makeButton("پنل راننده"){showDriver()}); addGap(body,10); body.addView(makeButton("خانه"){showHome()}) }
}
