package ir.shabro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 11)
    private val panel = Color.rgb(19, 20, 24)
    private val panel2 = Color.rgb(27, 27, 29)
    private val gold = Color.rgb(245, 190, 66)
    private val pale = Color.rgb(242, 232, 205)
    private val muted = Color.rgb(165, 158, 143)
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun label(s: String, size: Float, color: Int = pale, bold: Boolean = false, align: Int = Gravity.CENTER): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = align
        if (bold) setTypeface(null, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_RTL
        setLineSpacing(dp(3).toFloat(), 1f)
    }
    private fun makeButton(s: String, primary: Boolean = false, action: () -> Unit): TextView = label(s, 15f, if (primary) Color.rgb(20,18,13) else gold, true).apply {
        background = rounded(if (primary) gold else Color.rgb(14,15,18), 16, if (primary) 0 else Color.rgb(119,88,35))
        setPadding(dp(12), dp(14), dp(12), dp(14)); setOnClickListener { action() }
    }
    private fun addGap(parent: LinearLayout, h: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun sectionTitle(s: String): TextView = label(s, 18f, gold, true, Gravity.RIGHT).apply { setPadding(0, dp(8), dp(2), dp(12)) }

    private fun shell(title: String, showNav: Boolean = true) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(18)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (showNav) root.addView(bottomNav())
        setContentView(root)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(8), dp(2), dp(8)) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.shabro_logo); scaleType = ImageView.ScaleType.FIT_CENTER }
        header.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        header.addView(label(title, 25f, gold, true, Gravity.RIGHT or Gravity.CENTER_VERTICAL), LinearLayout.LayoutParams(0, dp(58), 1f))
        header.addView(label("☰", 25f, pale), LinearLayout.LayoutParams(dp(42), dp(48)))
        body.addView(header)
    }

    private fun bottomNav(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(14,15,18)); setPadding(dp(5), dp(7), dp(5), dp(7))
        val items = listOf("⌂\nخانه", "▣\nسفارش‌ها", "▤\nکیف پول", "●\nپروفایل")
        items.forEachIndexed { i, s ->
            val v = label(s, 11f, if (i == 0) gold else muted, i == 0)
            addView(v, LinearLayout.LayoutParams(0, dp(48), 1f))
            v.setOnClickListener { if (i == 1) showOrders() else if (i == 3) showProfile() else showHome() }
        }
    }

    private fun showHome() {
        shell("شب‌رو")
        // Brand tagline and compact premium header
        body.addView(label("سفر امن، در هر زمان، در سراسر ایران", 13f, muted, false, Gravity.RIGHT),
            LinearLayout.LayoutParams(-1, dp(30)))
        addGap(body, 6)

        // Large live-style map card, matching the approved passenger home screen
        val map = FrameLayout(this).apply {
            background = rounded(Color.rgb(221, 224, 213), 20)
            clipToOutline = true
        }
        map.addView(RoadMap(this), FrameLayout.LayoutParams(-1, dp(218)))
        val mapInfo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(12, 13, 16), 16, Color.rgb(83, 65, 35))
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        mapInfo.addView(label("🔵   مبدأ را انتخاب کنید", 14f, pale, true, Gravity.RIGHT))
        addGap(mapInfo, 5)
        mapInfo.addView(View(this).apply { setBackgroundColor(Color.rgb(48, 48, 47)) }, LinearLayout.LayoutParams(-1, dp(1)))
        addGap(mapInfo, 5)
        mapInfo.addView(label("📍   مقصد را انتخاب کنید", 14f, pale, true, Gravity.RIGHT))
        val infoParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            setMargins(dp(10), 0, dp(10), dp(10))
        }
        map.addView(mapInfo, infoParams)
        body.addView(map, LinearLayout.LayoutParams(-1, dp(238)))
        addGap(body, 14)

        // Two prominent gold/black service tiles
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val trip = serviceTile("🚘", "درخواست سفر") { showBooking("درخواست سفر") }
        val cargo = serviceTile("📦", "ارسال بار و بسته") { showBooking("ارسال بار و بسته") }
        actions.addView(trip, LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginEnd = dp(6) })
        actions.addView(cargo, LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginStart = dp(6) })
        body.addView(actions)
        addGap(body, 14)

        // Real photographic promo artwork taken from the approved visual reference
        val promo = FrameLayout(this).apply {
            background = rounded(Color.rgb(23, 19, 13), 18, Color.rgb(145, 103, 32))
            clipToOutline = true
        }
        val promoImage = ImageView(this).apply {
            setImageResource(R.drawable.night_car_promo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.92f
        }
        promo.addView(promoImage, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.TRANSPARENT, Color.argb(205, 0, 0, 0)))
        }
        promo.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val promoText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setPadding(dp(12), dp(8), dp(14), dp(8))
            addView(label("شب‌رو", 21f, gold, true, Gravity.RIGHT))
            addView(label("همیشه در کنار شماست", 12f, pale, true, Gravity.RIGHT))
        }
        promo.addView(promoText, FrameLayout.LayoutParams(-1, -1))
        body.addView(promo, LinearLayout.LayoutParams(-1, dp(100)))
        addGap(body, 14)

        val features = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(16, 17, 20), 18, Color.rgb(66, 53, 31))
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        listOf("🛡\nامنیت بالا", "🎧\nپشتیبانی", "⚡\nسفارش سریع", "📍\nپوشش سراسری").forEach {
            features.addView(label(it, 10f, gold, true), LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        body.addView(features)
        addGap(body, 12)
        body.addView(makeButton("پنل راننده", false) { showDriver() }, LinearLayout.LayoutParams(-1, dp(48)))
    }

    private fun serviceTile(symbol: String, title: String, action: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(8, 9, 12), 18, Color.rgb(177, 126, 37))
            elevation = dp(3).toFloat()
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(label(symbol, 34f, gold, true), LinearLayout.LayoutParams(-1, dp(54)))
            addView(label(title, 13f, pale, true), LinearLayout.LayoutParams(-1, dp(30)))
            setOnClickListener { action() }
        }

    private class RoadMap(ctx: android.content.Context) : View(ctx) {
        private val block = Paint(3).apply { color = Color.rgb(204, 215, 198); strokeWidth = 1.5f; style = Paint.Style.STROKE }
        private val minor = Paint(3).apply { color = Color.rgb(250, 249, 239); strokeWidth = 9f; style = Paint.Style.STROKE }
        private val major = Paint(3).apply { color = Color.rgb(242, 190, 79); strokeWidth = 13f; style = Paint.Style.STROKE }
        private val route = Paint(3).apply { color = Color.rgb(45, 126, 221); strokeWidth = 6f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val blue = Paint(3).apply { color = Color.rgb(38, 125, 235); style = Paint.Style.FILL }
        private val white = Paint(3).apply { color = Color.WHITE; style = Paint.Style.FILL }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            c.drawColor(Color.rgb(226, 229, 218))
            for (i in 0..8) {
                val x = w * i / 8f
                c.drawLine(x, 0f, x + w * .16f, h, block)
                val y = h * i / 8f
                c.drawLine(0f, y, w, y - h * .10f, block)
            }
            val d1 = Path().apply { moveTo(-20f, h*.18f); lineTo(w*.35f,h*.36f); lineTo(w*.62f,h*.24f); lineTo(w+20,h*.40f) }
            val d2 = Path().apply { moveTo(w*.08f,h+20); lineTo(w*.36f,h*.62f); lineTo(w*.72f,h*.50f); lineTo(w*.92f,-20f) }
            c.drawPath(d1, minor); c.drawPath(d2, major)
            val r = Path().apply { moveTo(w*.30f,h*.70f); lineTo(w*.43f,h*.58f); lineTo(w*.55f,h*.47f); lineTo(w*.72f,h*.25f) }
            c.drawPath(r, route)
            c.drawCircle(w*.30f,h*.70f,dp(10).toFloat(),white)
            c.drawCircle(w*.30f,h*.70f,dp(7).toFloat(),blue)
            c.drawCircle(w*.72f,h*.25f,dp(8).toFloat(),white)
            c.drawCircle(w*.72f,h*.25f,dp(5).toFloat(),Paint(3).apply { color = Color.rgb(220,60,55); style = Paint.Style.FILL })
        }
    }

    private fun showBooking(kind: String) {
        shell(kind, false)
        body.addView(sectionTitle("ثبت درخواست جدید"))
        listOf("مبدأ سفر", "مقصد سفر", "شهر یا نشانی مبدأ", "شهر یا نشانی مقصد", "زمان سفر", "شماره تماس").forEach { hint ->
            val e = EditText(this).apply { this.hint = hint; setHintTextColor(muted); setTextColor(pale); textSize = 15f; background = rounded(panel2, 14); setPadding(dp(14), 0, dp(14), 0); gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL; textDirection = View.TEXT_DIRECTION_RTL }
            body.addView(e, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(12) })
        }
        body.addView(makeButton("محاسبه کرایه", true) { Toast.makeText(this, "محاسبه آنلاین کرایه در نسخه آزمایشی فعال نیست", Toast.LENGTH_LONG).show() }, LinearLayout.LayoutParams(-1, dp(62)))
        addGap(body, 12)
        body.addView(makeButton("بازگشت به صفحه اصلی") { showHome() }, LinearLayout.LayoutParams(-1, dp(56)))
    }
    private fun showDriver() {
        shell("پنل راننده", false)
        body.addView(sectionTitle("سلام، راننده عزیز"))
        body.addView(label("●  وضعیت: آفلاین", 15f, gold, true), LinearLayout.LayoutParams(-1, dp(48)))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(stat("۲۸", "تعداد سفرها"), LinearLayout.LayoutParams(0, dp(110), 1f).apply { marginEnd = dp(6) })
        stats.addView(stat("۲٬۴۵۰٬۰۰۰", "درآمد امروز (تومان)"), LinearLayout.LayoutParams(0, dp(110), 1f).apply { marginStart = dp(6) })
        body.addView(stats)
        addGap(body, 14)
        body.addView(makeButton("نمایش نقشه و درخواست‌ها", true) { Toast.makeText(this,"اتصال آنلاین در نسخه بعدی فعال می‌شود",Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1,dp(58)))
        addGap(body, 10); body.addView(makeButton("تنظیمات مدیریت") { showAdmin() }, LinearLayout.LayoutParams(-1,dp(56)))
        addGap(body, 10); body.addView(makeButton("بازگشت به خانه") { showHome() }, LinearLayout.LayoutParams(-1,dp(56)))
    }
    private fun stat(value: String, caption: String) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(panel,18,Color.rgb(90,67,30)); addView(label(value,20f,gold,true)); addView(label(caption,12f,muted)) }
    private fun showAdmin() {
        shell("تنظیمات مدیریت", false)
        body.addView(sectionTitle("مدیریت سامانه شب‌رو"))
        body.addView(stat("۵٪", "کمیسیون پلتفرم از هر سفارش"), LinearLayout.LayoutParams(-1,dp(115)))
        listOf("تعرفه‌ها و قیمت‌گذاری", "مدیریت کاربران", "گزارش‌گیری و آمار", "تنظیمات پیشرفته").forEach { s -> addGap(body,9); body.addView(label("‹     $s",16f,pale,true,Gravity.RIGHT).apply { background=rounded(panel,14); setPadding(dp(14),dp(16),dp(14),dp(16)) },LinearLayout.LayoutParams(-1,dp(58))) }
        addGap(body,14); body.addView(makeButton("بازگشت به پنل راننده") { showDriver() },LinearLayout.LayoutParams(-1,dp(54)))
        addGap(body,10); body.addView(makeButton("خانه") { showHome() },LinearLayout.LayoutParams(-1,dp(54)))
    }
    private fun showOrders() { shell("سفارش‌های من", false); body.addView(label("هنوز سفارشی ثبت نکرده‌اید",16f,muted),LinearLayout.LayoutParams(-1,dp(150))); body.addView(makeButton("ثبت درخواست جدید",true){showBooking("درخواست سفر")}) }
    private fun showProfile() { shell("پروفایل کاربری", false); body.addView(label("به شب‌رو خوش آمدید",18f,gold,true),LinearLayout.LayoutParams(-1,dp(90))); body.addView(makeButton("پنل راننده"){showDriver()}); addGap(body,10); body.addView(makeButton("خانه"){showHome()}) }
}
