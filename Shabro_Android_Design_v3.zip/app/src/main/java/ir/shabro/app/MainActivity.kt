package ir.shabro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 12)
    private val panel = Color.rgb(29, 27, 22)
    private val gold = Color.rgb(242, 193, 78)
    private val cream = Color.rgb(247, 239, 219)
    private val muted = Color.rgb(190, 180, 155)
    private val orders = mutableListOf<Order>()
    private var basePassenger = 30000.0
    private var perKmPassenger = 8000.0
    private var baseCargo = 50000.0
    private var perKmCargo = 12000.0
    private var nightPercent = 20.0
    private var commission = 5.0
    private var currentQuote = 0.0
    private var currentTab = "customer"
    private lateinit var content: LinearLayout
    private lateinit var root: LinearLayout

    data class Order(val kind:String, val from:String, val to:String, val km:Int, val price:Double, var status:String="در انتظار راننده")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        showApp()
    }

    private fun showApp() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        val header = LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(20),dp(18),dp(20),dp(18)); setBackgroundColor(Color.rgb(9,10,12))
        }
        val brand = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL }
        brand.addView(label("شب‌رو", 27f, gold, true))
        brand.addView(label("سفر، بار و بسته؛ با اطمینان", 12f, muted))
        header.addView(brand, LinearLayout.LayoutParams(0,-2,1f))
        val mark=TextView(this).apply { text="ش"; textSize=25f; gravity=Gravity.CENTER; setTextColor(gold); typeface=Typeface.DEFAULT_BOLD; background=shape(Color.rgb(38,31,17),gold,dp(18)) }
        header.addView(mark,LinearLayout.LayoutParams(dp(52),dp(52)))
        root.addView(header)
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(dp(10),dp(10),dp(10),dp(10)); gravity=Gravity.CENTER; setBackgroundColor(Color.rgb(13,14,16)) }
        listOf("خانه" to "customer", "راننده" to "driver", "سفارش‌ها" to "orders", "مدیریت" to "admin").forEach { (title,key) ->
            val active=currentTab==key
            val b=TextView(this).apply {
                text=(when(key){"customer"->"⌂  ";"driver"->"◉  ";"orders"->"▤  ";else->"⚙  "})+title
                textSize=11f; gravity=Gravity.CENTER; setPadding(dp(3),dp(13),dp(3),dp(13))
                setTextColor(if(active) gold else muted); background=shape(if(active) Color.rgb(45,36,19) else Color.TRANSPARENT,if(active) gold else Color.TRANSPARENT,dp(14))
                setOnClickListener { currentTab=key; showContent() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0,dp(48),1f).apply { setMargins(dp(3),0,dp(3),0) })
        }
        root.addView(nav)
        val scroll=ScrollView(this).apply { isFillViewport=true }
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,8,14,20) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        showContent()
    }

    private fun showContent() {
        content.removeAllViews()
        when(currentTab) {
            "customer" -> customerPage()
            "driver" -> driverPage()
            "orders" -> ordersPage()
            "admin" -> adminPage()
        }
    }

    private fun customerPage() {
        val hero=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(18),dp(20),dp(20)); background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(54,42,20),Color.rgb(20,20,19),Color.rgb(14,15,18))).apply { cornerRadius=dp(22).toFloat(); setStroke(dp(1),Color.rgb(112,83,34)) } }
        hero.addView(label("سفر تو، با یک لمس شروع می‌شه",21f,cream,true))
        hero.addView(label("درخواست سفر یا ارسال بار؛ سریع، روشن و مطمئن",13f,muted))
        hero.addView(label("شب‌رو  •  همراه مسیرهای تو در سراسر ایران",12f,gold,true))
        content.addView(hero,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(12) })
        content.addView(MapPreview(), LinearLayout.LayoutParams(-1,dp(190)).apply { bottomMargin=dp(14) })
        card("از شب‌رو چه خدمتی می‌خوای؟") {
            val choices=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
            listOf("🚘\nدرخواست خودرو","📦\nارسال بار و بسته").forEach { title ->
                val tile=TextView(this@MainActivity).apply { text=title; textSize=16f; gravity=Gravity.CENTER; setTextColor(cream); typeface=Typeface.DEFAULT_BOLD; setPadding(dp(8),dp(18),dp(8),dp(18)); background=shape(Color.rgb(38,32,22),Color.rgb(111,82,34),dp(16)) }
                choices.addView(tile,LinearLayout.LayoutParams(0,dp(94),1f).apply { setMargins(dp(4),0,dp(4),0) })
            }
            addView(choices)
        }
        card("درخواست جدید") {
            val kind=spinner(listOf("جابه‌جایی مسافر","حمل بار و بسته"))
            val vehicle=spinner(listOf("سواری","وانت","کامیونت"))
            val from=edit("شهر یا نشانی مبدأ")
            val to=edit("شهر یا نشانی مقصد")
            val km=edit("مسافت تقریبی به کیلومتر", true)
            val period=spinner(listOf("شب","روز"))
            val phone=edit("شماره تماس")
            addView(kind); addView(vehicle); addView(from); addView(to); addView(km); addView(period); addView(phone)
            val quote=label("کرایه پس از محاسبه نمایش داده می‌شود",18f,gold,true)
            addView(quote)
            addView(actionButton("محاسبه کرایه") {
                val distance=km.text.toString().toIntOrNull() ?: 0
                if(from.text.isBlank() || to.text.isBlank() || distance<=0) {
                    toast("مبدأ، مقصد و مسافت معتبر را وارد کن.")
                } else {
                    val cargo=kind.selectedItemPosition==1
                    val raw=(if(cargo) baseCargo else basePassenger)+distance*(if(cargo) perKmCargo else perKmPassenger)
                    currentQuote=raw*(if(period.selectedItemPosition==0) 1+nightPercent/100 else 1.0)
                    quote.text="کرایه تخمینی: ${money(currentQuote)}\nکمیسیون شب‌رو: ${money(currentQuote*commission/100)}"
                }
            })
            addView(actionButton("ثبت سفارش آزمایشی") {
                val distance=km.text.toString().toIntOrNull() ?: 0
                if(currentQuote<=0 || distance<=0 || from.text.isBlank() || to.text.isBlank()) toast("ابتدا اطلاعات را کامل و کرایه را محاسبه کن.")
                else {
                    orders.add(0,Order(if(kind.selectedItemPosition==0) "مسافر" else "بار",from.text.toString(),to.text.toString(),distance,currentQuote))
                    currentQuote=0.0; toast("سفارش آزمایشی ثبت شد."); currentTab="orders"; showContent()
                }
            })
        }
        card("شب‌رو در یک نگاه") {
            addView(label("نوع خدمات:  مسافر   و   بار",16f,cream,true))
            addView(label("محدوده فعالیت:  سراسر ایران",16f,cream,true))
            addView(label("کمیسیون اولیه:  ۵ درصد",16f,gold,true))
            addView(label("این نسخه برای بررسی ظاهر و جریان کار است. هنوز به سرور، نقشه، پیامک و پرداخت واقعی متصل نیست.",13f,muted))
        }
    }

    private fun driverPage() {
        card("پنل راننده") {
            addView(label("درخواست‌های ثبت‌شده در همین گوشی",14f,muted))
            val open=orders.filter { it.status=="در انتظار راننده" }
            if(open.isEmpty()) addView(label("فعلاً سفارش بازی وجود ندارد.",14f,muted))
            open.forEach { o ->
                addView(label("${o.kind}: ${o.from}  ←  ${o.to}",15f,cream,true))
                addView(label("${o.km} کیلومتر  •  ${money(o.price)}",13f,muted))
                addView(actionButton("قبول سفارش") { o.status="راننده پذیرفت"; toast("سفارش در نسخه آزمایشی پذیرفته شد."); showContent() })
                addView(space())
            }
        }
        card("مشخصات راننده (نمونه)") {
            addView(edit("نام راننده")); addView(edit("شماره تماس")); addView(edit("نوع خودرو")); addView(edit("شهر فعالیت"))
            addView(label("احراز هویت و مدارک راننده در نسخه آنلاین اضافه می‌شود.",12f,muted))
        }
    }

    private fun ordersPage() {
        card("سفارش‌ها") {
            if(orders.isEmpty()) addView(label("هنوز سفارشی ثبت نشده است.",14f,muted))
            orders.forEach { o ->
                addView(label("${o.kind}  •  ${o.status}",16f,gold,true))
                addView(label("${o.from}  ←  ${o.to}",15f,cream))
                addView(label("${o.km} کیلومتر  •  ${money(o.price)}",13f,muted))
                addView(space())
            }
        }
    }

    private fun adminPage() {
        card("تنظیم تعرفه‌های آزمایشی (تومان)") {
            val pb=edit("پایه مسافر",true).apply { setText(basePassenger.toInt().toString()) }
            val pk=edit("هزینه هر کیلومتر مسافر",true).apply { setText(perKmPassenger.toInt().toString()) }
            val cb=edit("پایه بار",true).apply { setText(baseCargo.toInt().toString()) }
            val ck=edit("هزینه هر کیلومتر بار",true).apply { setText(perKmCargo.toInt().toString()) }
            val night=edit("افزایش شب‌کاری درصد",true).apply { setText(nightPercent.toInt().toString()) }
            val fee=edit("کمیسیون درصد",true).apply { setText(commission.toInt().toString()) }
            listOf(pb,pk,cb,ck,night,fee).forEach { addView(it) }
            addView(actionButton("ذخیره تعرفه‌ها") {
                basePassenger=pb.num(basePassenger); perKmPassenger=pk.num(perKmPassenger)
                baseCargo=cb.num(baseCargo); perKmCargo=ck.num(perKmCargo)
                nightPercent=night.num(nightPercent); commission=fee.num(commission)
                toast("تعرفه‌های نمونه ذخیره شد.")
            })
        }
        card("یادآوری") { addView(label("نرخ‌ها فرضی هستند و قبل از بهره‌برداری باید بر اساس شهر، مسیر، هزینه سوخت و قوانین روز تعیین شوند.",13f,muted)) }
    }

    private inner class MapPreview : View(this@MainActivity) {
        private val road=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(72,68,57); strokeWidth=dp(7).toFloat(); style=Paint.Style.STROKE; strokeCap=Paint.Cap.ROUND }
        private val thin=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(48,54,51); strokeWidth=dp(2).toFloat(); style=Paint.Style.STROKE }
        private val route=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=gold; strokeWidth=dp(4).toFloat(); style=Paint.Style.STROKE; strokeCap=Paint.Cap.ROUND }
        private val dot=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=gold; style=Paint.Style.FILL }
        private val white=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cream; textSize=dp(12).toFloat(); typeface=Typeface.DEFAULT_BOLD }
        override fun onDraw(c:Canvas) {
            super.onDraw(c); c.drawColor(Color.rgb(22,27,27))
            val w=width.toFloat(); val h=height.toFloat()
            for(i in 1..5) { val y=h*i/6f; c.drawLine(0f,y,w,y+dp(18),thin); val x=w*i/6f; c.drawLine(x,0f,x-dp(22),h,thin) }
            val p=Path().apply { moveTo(w*.12f,h*.78f); cubicTo(w*.32f,h*.7f,w*.48f,h*.3f,w*.82f,h*.24f) }
            c.drawPath(p,road); c.drawPath(p,route)
            c.drawCircle(w*.12f,h*.78f,dp(8).toFloat(),dot); c.drawCircle(w*.82f,h*.24f,dp(8).toFloat(),dot)
            c.drawRoundRect(w*.05f,h*.06f,w*.48f,h*.23f,dp(12).toFloat(),dp(12).toFloat(),Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.argb(220,12,12,12) })
            c.drawText("محدوده‌ی سفر روی نقشه",w*.09f,h*.17f,white)
        }
        init { background=shape(Color.rgb(22,27,27),Color.rgb(105,79,35),dp(20)); clipToOutline=true }
    }

    private fun card(title:String, body:LinearLayout.()->Unit) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(17),dp(16),dp(17),dp(18)); background=shape(Color.rgb(25,26,28),Color.rgb(54,49,39),dp(20)) }
        box.addView(label(title,19f,gold,true))
        box.addView(space(8))
        box.body()
        content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(14) })
    }
    private fun label(text:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply {
        this.text=text; textSize=size; setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD)
        gravity=Gravity.RIGHT; setPadding(2,dp(7),2,dp(7)); textDirection=View.TEXT_DIRECTION_RTL
        layoutDirection=View.LAYOUT_DIRECTION_RTL
    }
    private fun edit(hint:String,numeric:Boolean=false)=EditText(this).apply {
        this.hint=hint; textSize=14f; setTextColor(cream); setHintTextColor(muted)
        setSingleLine(true); setPadding(dp(14),dp(10),dp(14),dp(10))
        background=shape(Color.rgb(15,17,19),Color.rgb(65,60,49),dp(12)); inputType=if(numeric) 2 else 1
        setTextColor(Color.WHITE); setHintTextColor(Color.rgb(160,157,148));
        layoutDirection=View.LAYOUT_DIRECTION_RTL
        val lp=LinearLayout.LayoutParams(-1,dp(52)); lp.bottomMargin=dp(9); this.layoutParams=lp
    }
    private fun spinner(items:List<String>)=Spinner(this).apply {
        adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        setBackground(shape(Color.rgb(15,17,19),Color.rgb(65,60,49),dp(12)))
        layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply { bottomMargin=dp(9) }
    }
    private fun actionButton(text:String,onClick:()->Unit)=Button(this).apply {
        this.text=text; textSize=14f; isAllCaps=false; setTextColor(Color.rgb(20,18,14)); typeface=Typeface.DEFAULT_BOLD
        background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Color.rgb(255,220,137),gold,Color.rgb(190,139,43))).apply { cornerRadius=dp(14).toFloat() }
        elevation=dp(2).toFloat(); setOnClickListener { onClick() }
        layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply { topMargin=dp(6); bottomMargin=dp(6) }
    }
    private fun shape(fill:Int,stroke:Int,radius:Int)=GradientDrawable().apply { setColor(fill); cornerRadius=radius.toFloat(); if(stroke!=Color.TRANSPARENT) setStroke(dp(1),stroke) }
    private fun space(h:Int=12)=View(this).apply { layoutParams=LinearLayout.LayoutParams(1,dp(h)) }
    private fun money(n:Double)=NumberFormat.getNumberInstance(Locale("fa","IR")).format(n.toLong())+" تومان"
    private fun EditText.num(default:Double)=text.toString().toDoubleOrNull() ?: default
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
