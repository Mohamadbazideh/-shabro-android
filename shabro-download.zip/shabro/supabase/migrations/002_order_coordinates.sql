-- Add coordinate-aware order creation. Run after 001_initial_schema.sql.
create or replace function public.create_order(
  p_kind public.order_kind,
  p_origin_text text,
  p_destination_text text,
  p_description text default null,
  p_estimated_fare bigint default null,
  p_origin_lat double precision default null,
  p_origin_lng double precision default null,
  p_destination_lat double precision default null,
  p_destination_lng double precision default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_id uuid;
  v_fare bigint;
begin
  if auth.uid() is null then raise exception 'ابتدا وارد حساب کاربری شوید'; end if;
  if coalesce(trim(p_origin_text),'') = '' or coalesce(trim(p_destination_text),'') = '' then raise exception 'مبدأ و مقصد الزامی است'; end if;
  if (p_origin_lat is null) <> (p_origin_lng is null) or (p_destination_lat is null) <> (p_destination_lng is null) then
    raise exception 'مختصات مبدأ و مقصد باید کامل باشند';
  end if;
  if p_origin_lat not between -90 and 90 or p_destination_lat not between -90 and 90
     or p_origin_lng not between -180 and 180 or p_destination_lng not between -180 and 180 then
    if p_origin_lat is not null or p_origin_lng is not null or p_destination_lat is not null or p_destination_lng is not null then
      raise exception 'مختصات جغرافیایی نامعتبر است';
    end if;
  end if;
  if exists(select 1 from public.profiles where id=auth.uid() and (is_suspended or role <> 'passenger')) then raise exception 'این حساب مجاز به ثبت سفارش نیست'; end if;
  select greatest(minimum_fare, coalesce(p_estimated_fare, minimum_fare)) into v_fare from public.fare_settings where id=1;
  insert into public.rides(passenger_id,kind,origin_text,destination_text,origin_lat,origin_lng,destination_lat,destination_lng,description,estimated_fare)
  values(auth.uid(),p_kind,trim(p_origin_text),trim(p_destination_text),p_origin_lat,p_origin_lng,p_destination_lat,p_destination_lng,nullif(trim(p_description),''),v_fare)
  returning id into v_id;
  return v_id;
end; $$;

grant execute on function public.create_order(public.order_kind,text,text,text,bigint,double precision,double precision,double precision,double precision) to authenticated;
