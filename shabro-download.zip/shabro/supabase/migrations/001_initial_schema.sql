-- شب‌رو: initial production-oriented schema (PostgreSQL / Supabase)
create extension if not exists pgcrypto;

create type public.user_role as enum ('passenger','driver','admin');
create type public.order_kind as enum ('ride','parcel');
create type public.order_status as enum ('pending','accepted','arriving','in_progress','completed','cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique,
  full_name text,
  role public.user_role not null default 'passenger',
  is_verified boolean not null default false,
  is_suspended boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.rides (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id),
  driver_id uuid references public.profiles(id),
  kind public.order_kind not null default 'ride',
  status public.order_status not null default 'pending',
  origin_text text not null,
  destination_text text not null,
  origin_lat double precision,
  origin_lng double precision,
  destination_lat double precision,
  destination_lng double precision,
  description text,
  estimated_fare bigint not null check (estimated_fare >= 0),
  final_fare bigint,
  platform_commission bigint,
  driver_earning bigint,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  balance bigint not null default 0 check (balance >= 0),
  updated_at timestamptz not null default now()
);

create table public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  ride_id uuid references public.rides(id),
  amount bigint not null,
  kind text not null check (kind in ('topup','ride_payment','driver_payout','commission','refund','adjustment')),
  description text,
  created_at timestamptz not null default now()
);

create table public.fare_settings (
  id integer primary key default 1 check (id = 1),
  base_fare bigint not null default 30000,
  per_km_fare bigint not null default 12000,
  minimum_fare bigint not null default 50000,
  commission_percent numeric(5,2) not null default 5.00 check (commission_percent between 0 and 30),
  updated_at timestamptz not null default now()
);
insert into public.fare_settings(id) values (1) on conflict do nothing;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, phone, role) values (new.id, new.phone, 'passenger') on conflict (id) do nothing;
  insert into public.wallets(user_id) values (new.id) on conflict (user_id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin' and is_suspended = false);
$$;

create or replace function public.create_order(
  p_kind public.order_kind,
  p_origin_text text,
  p_destination_text text,
  p_description text default null,
  p_estimated_fare bigint default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_id uuid;
  v_fare bigint;
begin
  if auth.uid() is null then raise exception 'ابتدا وارد حساب کاربری شوید'; end if;
  if coalesce(trim(p_origin_text),'') = '' or coalesce(trim(p_destination_text),'') = '' then raise exception 'مبدأ و مقصد الزامی است'; end if;
  if exists(select 1 from public.profiles where id=auth.uid() and (is_suspended or role <> 'passenger')) then raise exception 'این حساب مجاز به ثبت سفارش نیست'; end if;
  select greatest(minimum_fare, coalesce(p_estimated_fare, minimum_fare)) into v_fare from public.fare_settings where id=1;
  insert into public.rides(passenger_id,kind,origin_text,destination_text,description,estimated_fare)
  values(auth.uid(),p_kind,trim(p_origin_text),trim(p_destination_text),nullif(trim(p_description),''),v_fare)
  returning id into v_id;
  return v_id;
end; $$;

grant execute on function public.create_order(public.order_kind,text,text,text,bigint) to authenticated;

alter table public.profiles enable row level security;
alter table public.rides enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.fare_settings enable row level security;

create policy "profile owner or admin can read" on public.profiles for select to authenticated using (id=auth.uid() or public.is_admin());
create policy "profile owner can update safe fields" on public.profiles for update to authenticated using (id=auth.uid() and role='passenger') with check (id=auth.uid() and role='passenger');
create policy "passenger and assigned driver can read order" on public.rides for select to authenticated using (passenger_id=auth.uid() or driver_id=auth.uid() or public.is_admin());
create policy "admin can update orders" on public.rides for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "wallet owner or admin can read" on public.wallets for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "transactions owner or admin can read" on public.wallet_transactions for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "authenticated can read fare settings" on public.fare_settings for select to authenticated using (true);
create policy "admin can update fare settings" on public.fare_settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Driver verification, assignment, payment settlement and refunds must be performed
-- by trusted server-side functions after business rules and gateway callbacks are implemented.
