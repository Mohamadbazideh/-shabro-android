import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
export const isBackendConfigured = Boolean(url && key && !url.includes('YOUR_PROJECT'));
export const supabase = isBackendConfigured ? createClient(url, key) : null;
