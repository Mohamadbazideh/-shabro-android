import React, { useMemo } from 'react';
import { View, Text } from 'react-native';
import { WebView } from 'react-native-webview';

const DEFAULT_CENTER = [35.699739, 51.338097];

/** Neshan's official Leaflet-based Web SDK hosted inside a WebView.
 * A Web SDK key from platform.neshan.org is required. Do not put service keys here.
 */
export default function NeshanMap({ apiKey, onPick, center = DEFAULT_CENTER, height = 230 }) {
  const html = useMemo(() => {
    const safeKey = JSON.stringify(apiKey || '');
    const safeCenter = JSON.stringify(center || DEFAULT_CENTER);
    return `<!doctype html><html lang="fa"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/><link rel="stylesheet" href="https://static.neshan.org/sdk/leaflet/1.4.0/leaflet.css"/><style>html,body,#map{height:100%;width:100%;margin:0;padding:0;background:#101010} .leaflet-container{font-family: sans-serif}</style></head><body><div id="map"></div><script src="https://static.neshan.org/sdk/leaflet/1.4.0/leaflet.js"></script><script>
      (function(){
        var key=${safeKey}; var center=${safeCenter};
        if(!key){document.getElementById('map').innerHTML='<div style="color:#f3bd36;background:#111;height:100%;display:flex;align-items:center;justify-content:center;text-align:center;padding:20px;box-sizing:border-box;direction:rtl;font:14px sans-serif">برای نمایش نقشه، کلید Web SDK نشان را در فایل .env وارد کنید.</div>';return;}
        try {
          var map = new L.Map('map',{key:key,maptype:'dreamy',poi:true,traffic:false,center:center,zoom:13});
          var marker=null;
          map.on('click',function(e){
            var p=[e.latlng.lat,e.latlng.lng];
            if(marker){marker.setLatLng(p);}else{marker=L.marker(p).addTo(map);}
            if(window.ReactNativeWebView){window.ReactNativeWebView.postMessage(JSON.stringify({type:'pick',lat:p[0],lng:p[1]}));}
          });
          window.addEventListener('message',function(event){try{var d=JSON.parse(event.data);if(d.type==='center'){map.setView([d.lat,d.lng],15);}}catch(e){}});
        } catch(e) { document.getElementById('map').innerHTML='<div style="color:#f3bd36;background:#111;height:100%;display:flex;align-items:center;justify-content:center;text-align:center;padding:20px;direction:rtl">بارگذاری نقشه نشان ناموفق بود. کلید و مجوز دامنه/اپلیکیشن را بررسی کنید.</div>'; }
      })();
    </script></body></html>`;
  }, [apiKey, center]);

  if (!apiKey) return <View style={{ height, backgroundColor: '#111', borderRadius: 15, alignItems: 'center', justifyContent: 'center', padding: 16 }}><Text style={{ color: '#F3BD36', textAlign: 'center', fontWeight: '700' }}>نقشه نشان انتخاب شد</Text><Text style={{ color: '#aaa', textAlign: 'center', marginTop: 8, fontSize: 12, lineHeight: 20 }}>برای نمایش نقشه زنده، کلید Web SDK نشان لازم است. آن را در EXPO_PUBLIC_NESHAN_WEB_KEY قرار دهید.</Text></View>;

  return <View style={{ height, overflow: 'hidden', borderRadius: 15, borderWidth: 1, borderColor: '#70531c' }}><WebView originWhitelist={['*']} source={{ html, baseUrl: 'https://platform.neshan.org' }} javaScriptEnabled domStorageEnabled onMessage={(event) => { try { const data = JSON.parse(event.nativeEvent.data); if (data.type === 'pick') onPick?.({ latitude: data.lat, longitude: data.lng }); } catch (_) {} }} /></View>;
}
